package com.lkere.barboracontrol;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference irStatus = database.getReference("control/irStatus");
    DatabaseReference uvStatus = database.getReference("control/uvStatus");
    DatabaseReference startHour = database.getReference("control/startHour");
    DatabaseReference startMinute = database.getReference("control/startMinute");
    DatabaseReference baskingTime = database.getReference("control/baskingTime");
    DatabaseReference overRide = database.getReference("control/overRide");

    int morningHour;
    int morningMinute;
    int baskTime;

        public String morningTime () {
            if (String.valueOf(morningHour).length() == 1 && String.valueOf(morningMinute).length() == 1) {
                return "0" + morningHour + ":" + "0" + morningMinute;
            } else if (String.valueOf(morningHour).length() == 2 && String.valueOf(morningMinute).length() == 1) {
                return morningHour + ":" + "0" + morningMinute;
            } else if (String.valueOf(morningHour).length() == 1 && String.valueOf(morningMinute).length() == 2) {
                return "0" + morningHour + ":" + morningMinute;
            } else {
                return morningHour + ":" + morningMinute;
            }
        }
        public String eveningTime () {
            int finalTime = baskTime + morningHour;
            if (finalTime >= 24) {
                finalTime = -24;
            }
            if (String.valueOf(finalTime).length() == 1 && String.valueOf(morningMinute).length() == 1) {
                return "0" + finalTime + ":" + morningMinute + "0";
            } else {
                return finalTime + ":" + morningMinute;
            }
        }

    public void uvOn (View view) {
        overRide.setValue(true);
        uvStatus.setValue(true);
    }
    public void uvOff (View view) {
        overRide.setValue(true);
        uvStatus.setValue(false);
    }
    public void irOn (View view) {
        overRide.setValue(true);
        irStatus.setValue(true);
    }
    public void irOff (View view) {
        overRide.setValue(true);
        irStatus.setValue(false);
    }
    public void endOverride (View view) {
        overRide.setValue(false);
    }
    public void changeStartTime (View view) {
        EditText editHour = findViewById(R.id.editHour);
        EditText editMinute = findViewById(R.id.editMinute);
        EditText basking = findViewById(R.id.baskingTime);
        if (TextUtils.isEmpty(editHour.getText().toString().trim()) ||
                TextUtils.isEmpty(editMinute.getText().toString().trim())) {
            Toast.makeText(this, "Enter something lol", Toast.LENGTH_SHORT).show();
        }
        else {
            int hour = Integer.parseInt(editHour.getText().toString());
            int minute = Integer.parseInt(editMinute.getText().toString());
            int baskTime = Integer.parseInt(basking.getText().toString());
            overRide.setValue(false);
            startHour.setValue(hour);
            startMinute.setValue(minute);
            baskingTime.setValue(baskTime);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView ovrdStatus = findViewById(R.id.ovrdStatus);
        final TextView irStatusText = findViewById(R.id.irStatus);
        final TextView uvStatusText = findViewById(R.id.uvStatus);
        final TextView startHourText = findViewById(R.id.startHourText);
        final TextView baskingTimeText = findViewById(R.id.baskingTimeText);
        final Button button = findViewById(R.id.button);


        overRide.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean status = dataSnapshot.getValue(boolean.class);
                if (status) {
                    ovrdStatus.setText("Overridden");
                    ovrdStatus.setTextColor(getColor(R.color.colorAccent));
                    button.setAlpha(1);
                }
                else {
                    ovrdStatus.setText("In Operation");
                    ovrdStatus.setTextColor(getColor(R.color.colorPrimary));
                    button.setAlpha(0);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(MainActivity.this, "Couldn't read", Toast.LENGTH_SHORT).show();
            }
        });

        irStatus.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean status = dataSnapshot.getValue(boolean.class);
                if (status) {
                    irStatusText.setText("IR ON");
                    irStatusText.setTextColor(getColor(R.color.colorPrimary));
                }
                else {
                    irStatusText.setText("IR OFF");
                    irStatusText.setTextColor(getColor(R.color.colorAccent));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(MainActivity.this, "Couldn't read", Toast.LENGTH_SHORT).show();
            }
        });
        uvStatus.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean status = dataSnapshot.getValue(boolean.class);
                if (status) {
                    uvStatusText.setText("UV ON");
                    uvStatusText.setTextColor(getColor(R.color.colorPrimary));
                }
                else {
                    uvStatusText.setText("UV OFF");
                    uvStatusText.setTextColor(getColor(R.color.colorAccent));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(MainActivity.this, "Couldn't read", Toast.LENGTH_SHORT).show();
            }
        });
        startHour.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int startHour = dataSnapshot.getValue(Integer.class);
                morningHour = startHour;
                    baskingTimeText.setText(eveningTime());
                    startHourText.setText(morningTime());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        startMinute.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int startMinute = dataSnapshot.getValue(Integer.class);
                morningMinute = startMinute;
                baskingTimeText.setText(eveningTime());
                startHourText.setText(morningTime());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        baskingTime.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int baskingTime = dataSnapshot.getValue(Integer.class);
                baskTime = baskingTime;
                baskingTimeText.setText(eveningTime());
                startHourText.setText(morningTime());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }



}
